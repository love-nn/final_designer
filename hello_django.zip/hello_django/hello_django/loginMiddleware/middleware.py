#### 自定义中间件的请求
import time
from django.utils.deprecation import MiddlewareMixin;#### 导入包文件
from django.http import JsonResponse;
from verificationApp.models import *
 
# 定义中间件的类方法
class Authorization(MiddlewareMixin):
    # 前置拦截器，请求前触发的方法
    def process_request(self,request):
        print("中间件触发")
        try:
            # 判断请求的如果不是登录的Api接口，判断token的内容
            if ('login' not in request.path and 'register' not in request.path):
                
                # 获取token值
                token = request.META.get("HTTP_TOKEN")
                print(token)
                # 没有传递token值
                if not token:
                    return JsonResponse({
                        'code':401,
                        'msg':'token无效'
                    })
 
                # 通过token值获取用户的信息，判断token是否合理
                
                user = usersInfo.objects.filter(token=token).first()
                print(user)
                # 没有token值
                if not user:
                    return JsonResponse({
                        'code':401,
                        'msg':'token不存在'
                    })
                # 判断用户的时间是否过期
                if user.expired_at < time.time():
                    return JsonResponse({
                        'code':401,
                        'msg':'token已经过期'
                    })
 
        except Exception:
 
            return JsonResponse({
                    'code':401,
                    'msg':'token无效'
                })