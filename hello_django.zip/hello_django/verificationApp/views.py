from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime  
from .models import usersInfo
from .models import ReserveInfo

import time
import jwt
import json
# 生成 token: jwt.encode(playload, key, algorithm='HS256')
# playload : 配置参数; key为app的SECRET_KEY(密钥); algorithm 为加密算法
info = {
         'exp': time.time() + 30000,  # jwt的过期时间，这个过期时间必须要大于签发时间
         'iat': time.time(),          # jwt的签发时间
         'iss': 'liyangsong',             # jwt签发者
         'data': {
         'userId': "",
         'timestamp': time.time()
        }
}
 

# 解密，校验签名
# s = jwt.decode(s, 'secret', issuer='lianzong', algorithms=['IsSuer'])  
# Create your views here.

def login(request):

    
    res = {

    }
    username = request.GET.get("username")
    password = request.GET.get("password")

    print(username)
    print(password)
    token    = request.META.get("TOKEN") 
    if  token  :
        s = jwt.decode(token, 'secret', issuer='liyangsong', algorithms=['IsSuer'])  
        print(s)
        curTime = time.time() ;
        if curTime >= s['exp']:
            res["msg"]    = "签名过期！"
            res["status"] = "error"
            res["code"] = "1001"
            return HttpResponse(json.dumps(res))
        user_obj = usersInfo.objects.filter(token = token)
    else :
        user_obj = usersInfo.objects.filter(username=username,password=password)
    


    if not user_obj :
        res["msg"]    = "密码不正确！"
        res["status"] = "error"
        res["code"] = "101"
        return HttpResponse(json.dumps(res))
    
    else :
        userId = user_obj.first().userID 
        info['data']['userId'] = userId
        expire_at = info["exp"]
        token = jwt.encode(info, "secret", algorithm="HS256")
        hierarchy = user_obj.first().Hierarchy
        nick = user_obj.first().nick 
        violationCount = user_obj.first().violationCount
        enable = user_obj.first().enable
        checkedIn = user_obj.first().checkIn
        updated_at_time = datetime.now()
        user_obj.update(token=token,expired_at=expire_at,updated_at=updated_at_time)
        updated_at = datetime.now().strftime("%Y-%m-%d")
        print(updated_at)
        res = {
            "status": "success",
            "msg": "登录成功",
            "data": {
                "token":token,
                "id":userId,
                "nick":nick,
                "hierarchy":hierarchy,
                "username":username,
                "violationCount":violationCount,
                "lastLogin":updated_at,
                "enabled":enable,
                "checkedIn":checkedIn
            },
        }
        return HttpResponse(json.dumps(res))


def getUserInfo(request):
    res = {

    }
    token    = request.META.get("HTTP_TOKEN") 
    if  token  :
        s = jwt.decode(token, 'secret', issuer='liyangsong', algorithms=['HS256'])  
        print(s)
        curTime = time.time() ;
        if curTime >= s['exp']:
            res["msg"]    = "签名过期！"
            res["status"] = "error"
            res["code"] = "1001"
            return HttpResponse(json.dumps(res))
    user_obj = usersInfo.objects.filter(token = token)


    if not user_obj :
        res["msg"]    = "未登录！"
        res["status"] = "error"
        res["code"] = "501"
        return HttpResponse(json.dumps(res))
    
    else :
        userId = user_obj.first().userID 
        hierarchy = user_obj.first().Hierarchy
        username = user_obj.first().username
        nick = user_obj.first().nick 
        updated_at = user_obj.first().updated_at
        violationCount = user_obj.first().violationCount
        enable = user_obj.first().enable
        checkedIn = user_obj.first().checkIn
        updated_at = updated_at.strftime("%Y-%m-%d")
        print(updated_at)
        res = {
            "status": "success",
            "msg": "登录成功",
            "data": {
                "id":userId,
                "nick":nick,
                "hierarchy":hierarchy,
                "username":username,
                "violationCount":violationCount,
                "lastLogin":updated_at,
                "enabled":enable,
                "checkedIn":checkedIn
            },
        }
        return HttpResponse(json.dumps(res))



def addReserveInfo(request):

    chaoxingUser = request.POST.get("chaoxingUsername")
    chaoxingPasswrod = request.POST.get("chaoxingPassword")
    phone = request.POST.get("phone")
    
    res = {

    }
    token    = request.META.get("TOKEN") 
    if  token  :
        s = jwt.decode(token, 'secret', issuer='liyangsong', algorithms=['HS256'])  
        print(s)
        curTime = time.time() ;
        if curTime >= s['exp']:
            res["msg"]    = "签名过期！"
            res["status"] = "error"
            res["code"] = "1001"
            return HttpResponse(json.dumps(res))
    user_obj = usersInfo.objects.filter(token = token)
    reserveInfo = ReserveInfo(userId=user_obj.first().userID,
        ChaoUser=chaoxingUser,ChaoPwd = chaoxingPasswrod, phone = phone)
    reserveInfo.save() 
    res["msg"]    = "上传成功"
    res["status"] = "success"
    res["code"] = "200"
    return HttpResponse(json.dumps(res))
