from django.http import HttpResponse
from verificationApp.models import usersInfo
import json
import re
def register(request):

    username   = request.POST.get("username")
    password   = request.POST.get("password")
    phone      = request.POST.get("phone")
    school     = request.POST.get("school")
    nick       = request.POST.get("nick") 
    
    #邮箱正则验证
    # my_emali = re.findall(r'^[0-9a-zA-Z_]{0,19}@[0-9a-zA-Z]{1,13}\.[com,cn,net]{2,3}$', email)
    # if not my_emali:
        # return HttpResponse({'message':'邮箱不正确'})

    newCounter = usersInfo(username=username,password=password,phone=phone,Hierarchy=0,nick=nick)
    newCounter.save()

    res = {
        "result": True,
        "msg": "",
        "code":"",
    }

    if not newCounter.userID:
        res["msg"]    = "创建失败"
        res["result"] = False
        res["code"] = "400" 
        return HttpResponse(json.dumps(res))
    else:
        res["msg"]    = "OK"
        res["result"] = True
        res["code"] = "200"
        return HttpResponse(json.dumps(res))

