from django.db import models
from datetime import datetime   


# Create your models here.

class usersInfo(models.Model):
    userID     = models.AutoField("用户ID",primary_key=True)
    username   = models.CharField("用户名",max_length=30)
    password   = models.CharField("密码",max_length=30)
    email      = models.CharField("邮箱",max_length=30)
    status     = models.CharField("状态",max_length=30,null=True)
    phone      = models.CharField("电话",max_length=30,null=True)
    Hierarchy  = models.IntegerField("层级",default=1) 
    enable     = models.BooleanField("状态",choices=((0,'关闭'),(1,'启用')),default=1,null=False)
    token      = models.CharField("token值",max_length=300,default="",null=True,unique=True)
    nick       = models.CharField("昵称",max_length=300,default="",unique=True)
    roles      = models.ManyToManyField("Roles")### 用户和角色多对多
    expired_at = models.IntegerField("过期时间",default=60*60*24*3)
    created_at = models.DateTimeField('创建时间',default=datetime.now,null=True)
    updated_at = models.DateTimeField("更新时间",default=datetime.now,null=True)
    school     = models.CharField("学校",max_length=50,null=False,default="门头沟")
    checkIn    = models.BooleanField("是否签到",choices=((0,'未签到'),(1,'签到')),default=1)
    violationCount = models.IntegerField("违约次数",default=0) 
    chaoxing   = models.ManyToManyField("ReserveInfo")
####角色列表
class Roles(models.Model):
    class Meta:
        db_table="crm_roles"
    role_name=models.CharField("角色名称",max_length=20,default="")
    role_desc = models.CharField("角色描述",max_length=50,default="")
    created_at = models.DateTimeField('创建时间',default=datetime.now,null=True)
    updated_at = models.DateTimeField("更新时间",default=datetime.now,null=True)


class Permissions(models.Model):
    class Meta:
        db_table="crm_permissions"
    pid = models.IntegerField("父级id",default=0)
    name = models.CharField("权限名称",max_length=20,default="")
    path = models.CharField("路由地址",max_length=40,default="")
    is_menu = models.SmallIntegerField("是否菜单",choices=((1,"是"),(2,"否")),default=1)
    icon = models.CharField("菜单图标",max_length=30,default="",null=True)
    sort = models.IntegerField("排序",default=10)
    access=models.CharField("权限标识",max_length=50,default="",null=True)
    roles=models.ManyToManyField("roles") ### 角色和权限多对多的关系
    created_at = models.DateTimeField('创建时间',default=datetime.now,null=True)
    updated_at = models.DateTimeField("更新时间",default=datetime.now,null=True)

class ReserveInfo(models.Model):
    userId    = models.AutoField("用户ID",primary_key=True)
    ChaoUser  = models.CharField(max_length=20)
    ChaoPwd   = models.CharField(max_length=20)
    stuId     = models.CharField(max_length=30)
    phone     = models.CharField(max_length=11)
    realName  = models.CharField(max_length=30)
    schoolId  = models.CharField(max_length=30)